import requests

def log_discord(webhook_url, message):
    try:
        requests.post(webhook_url, json={"content": message})
    except Exception as e:
        print(f"Discord logging error: {e}")

def log_telegram(token, chat_id, message):
    try:
        requests.get(f"https://api.telegram.org/bot{token}/sendMessage", params={"chat_id": chat_id, "text": message})
    except Exception as e:
        print(f"Telegram logging error: {e}")
